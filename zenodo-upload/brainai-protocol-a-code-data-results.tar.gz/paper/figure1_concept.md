# Figure 1 说明：几何标记预测力的二维边界

## 图的核心信息

几何标记（representational geometry markers）的预测力**不是普适的质量指标**，
它取决于**两个必须同时成立的条件**：

1. **标记与任务绑定**（task-relevant，如 GLUE 的 D_eff / Ψ_eff）
2. **存在分布偏移**，且偏移类型与之匹配

任一条件不成立，几何标记的优势就会消失——甚至在亮度/结构类偏移下
**被 ID 准确率反超**。

## 矩阵读法

| | 类别级偏移<br>CIFAR-10 → CIFAR-100 | 亮度 / 结构类<br>fog, brightness, contrast | 噪声 / 压缩类<br>gaussian_noise, pixelate, jpeg |
|---|---|---|---|
| **task-relevant 标记**<br>（GLUE 三指标） | **大幅领先**<br>D_eff ρ=+0.81<br>Ψ_eff ρ=+0.80<br>ID acc ρ=−0.61 | **优势反转**<br>ID acc ρ=+0.98<br>成为最强预测器<br>几何标记不占优 | **两者皆失效**<br>ID acc ρ≈0<br>几何标记亦不占优 |
| **通用几何量**<br>（PR, mean_dist…） | **有效但更弱**<br>PR ρ=+0.79<br>mean_dist ρ=+0.68<br>弱于 GLUE 但非失效 | **弱**<br>通用量在此失效<br>task-relevant 仍可用 | **弱**<br>所有预测器失效<br>需换指标族 |

## 底部红框：整个图的成立前提

> **前提：ID 受控 + 架构去混淆**
> 不做这两步，ID acc 的表观正相关（r = +0.48）是混淆假象，结论会完全反过来。

这是本图最容易被审稿人攻击的地方，也是本文方法论贡献的落点：
协议本身就是论证的一部分，不是脚注。

## 支撑数字出处

| 数字 | 来源 |
|---|---|
| D_eff ρ=+0.81、Ψ_eff ρ=+0.80 | `results/r1_final_report.md` T2 表（ID 受控 + 架构残差化） |
| ID acc ρ=−0.61 | 同上，`acc_test` 残差化后 Spearman |
| PR ρ=+0.79、mean_dist ρ=+0.68 | 同上 |
| fog/brightness ρ=+0.98~+0.99 | T5 表（corruption 场景细分） |
| gaussian_noise / pixelate / jpeg 失效 | T5 表 |
| pooled r=+0.48 | T2 表 `acc_test` 原始 r |

## 论文中的用法

放在 **Introduction 末尾 / Section 1 的贡献列表之前**，作为全文的"路线图"：
读者看图就知道我们要论证什么、边界在哪里。

对应正文 **§5.2** 的二维结构表。

## 绘制说明（给未来的自己）

- 绿色 `#E1F5EE` / 描边 `#0F6E56`：几何标记占优
- 琥珀 `#FAEEDA` / 描边 `#854F0B`：优势反转（本文的第二个核心发现）
- 灰色 `#F1EFE8`：失效区
- 红色 `#FCEBEB` / 描边 `#A32D2D`：方法论前提（必须显式画出）
- 全图不用渐变、不用阴影；每个格子里直接写数字，让图自解释

## 待办

- 独立验证跑完后，在图下方加一行小字：
  "边界结构在独立训练的 48 组模型上复现（见 §4.7）"
- 若 bootstrap CI 完成，在各格数字后标注 CI。
